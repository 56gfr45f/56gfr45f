# Smart-Youtube-Playlist-Downloader


Download all videos from YouTube playlist.
<h1>Features</h1>
<ul>
  <li>super fast downloading with threading</li>
  <li>resume from where your download left<li>
<ul>
<h1>Usage</h1>
<p>First install all require modules
  <ul>
    <li>pip3 install -r requirements.txt</li>
  </ul>
  <br>
<p>Steps to follow:</p>
  <p>Step 1: copy any youtube playlist link</p>
  <p>Step 2: $ python3 yt_playlist_downloader.py yt_playlist_link</p>
  <h1>Proof</h1>
  <img src="https://i.ibb.co/ydZtXTh/Screenshot-2022-03-16-00-18-03.png"/>
  <h1>Author</h1>
<ul>
  <li><a href="https://twitter.com/l1v1n9h311">Kunal Kumar</a></li>
  </ul>
  
